use bevy::prelude::*;

const DEFAULT_TICKS: u32 = 300;

fn main() {
    #[cfg(feature = "visible")]
    if std::env::args().any(|arg| arg == "--window") {
        ambition_demo_twintrack_app::build_windowed_demo_app().run();
        return;
    }

    let ticks = parse_ticks().unwrap_or(DEFAULT_TICKS);
    let mut app = ambition_demo_twintrack_app::build_demo_app();
    for _ in 0..ticks {
        app.update();
    }
    let view = app
        .world()
        .resource::<ambition_platformer2d::relativity2d::RelativityClockView2d>();
    println!("TwinTrack SR demo — {ticks} fixed host updates");
    println!("  spacetime: {}", view.model_id.unwrap_or("not active"));
    for (label, clock) in &view.clocks {
        println!(
            "  {label:10}: proper_time={:.6}s  speed={:.2}  rate={:.6}",
            clock.proper_time_seconds,
            clock.relative_velocity.length(),
            clock.proper_time_rate,
        );
    }
    println!("Run with `--features visible -- --window` to play the round trip.");
}

fn parse_ticks() -> Option<u32> {
    let mut args = std::env::args().skip(1);
    while let Some(arg) = args.next() {
        if arg == "--ticks" {
            return args.next()?.parse().ok();
        }
    }
    None
}
